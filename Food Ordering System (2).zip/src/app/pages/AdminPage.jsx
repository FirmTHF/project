import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useNavigate } from 'react-router';
import { mockMenu, mockRestaurants, mockOrders, mockOrderDetails } from '../data/mockData.js';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Plus, Pencil, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export function AdminPage() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [menuItems, setMenuItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingMenu, setEditingMenu] = useState(null);

  const [formData, setFormData] = useState({
    menu_name: '',
    restaurant_id: 1,
    description: '',
    price: 0,
    image_url: '',
    status: 'available'
  });

  useEffect(() => {
    if (currentUser?.role !== 'admin') {
      navigate('/');
      return;
    }

    const savedMenu = localStorage.getItem('menu');
    const savedOrders = localStorage.getItem('orders');

    setMenuItems(savedMenu ? JSON.parse(savedMenu) : mockMenu);
    setOrders(savedOrders ? JSON.parse(savedOrders) : mockOrders);
  }, [currentUser, navigate]);

  const handleSubmit = () => {
    if (!formData.menu_name || !formData.description || formData.price <= 0) {
      toast.error('กรุณากรอกข้อมูลให้ครบถ้วน');
      return;
    }

    if (editingMenu) {
      const updatedMenu = menuItems.map(m =>
        m.menu_id === editingMenu.menu_id
          ? { ...m, ...formData }
          : m
      );
      setMenuItems(updatedMenu);
      localStorage.setItem('menu', JSON.stringify(updatedMenu));
      toast.success('แก้ไขเมนูสำเร็จ');
    } else {
      const newMenu = {
        menu_id: menuItems.length + 1,
        ...formData
      };
      const updatedMenu = [...menuItems, newMenu];
      setMenuItems(updatedMenu);
      localStorage.setItem('menu', JSON.stringify(updatedMenu));
      toast.success('เพิ่มเมนูสำเร็จ');
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleDelete = (menuId) => {
    if (!confirm('ต้องการลบเมนูนี้หรือไม่?')) return;

    const updatedMenu = menuItems.filter(m => m.menu_id !== menuId);
    setMenuItems(updatedMenu);
    localStorage.setItem('menu', JSON.stringify(updatedMenu));
    toast.success('ลบเมนูสำเร็จ');
  };

  const handleEdit = (menu) => {
    setEditingMenu(menu);
    setFormData({
      menu_name: menu.menu_name,
      restaurant_id: menu.restaurant_id,
      description: menu.description,
      price: menu.price,
      image_url: menu.image_url,
      status: menu.status
    });
    setIsDialogOpen(true);
  };

  const toggleMenuStatus = (menuId) => {
    const updatedMenu = menuItems.map(m =>
      m.menu_id === menuId
        ? { ...m, status: m.status === 'available' ? 'unavailable' : 'available' }
        : m
    );
    setMenuItems(updatedMenu);
    localStorage.setItem('menu', JSON.stringify(updatedMenu));
    toast.success('อัพเดทสถานะสำเร็จ');
  };

  const updateOrderStatus = (orderId, status) => {
    const updatedOrders = orders.map(o =>
      o.order_id === orderId ? { ...o, status } : o
    );
    setOrders(updatedOrders);
    localStorage.setItem('orders', JSON.stringify(updatedOrders));
    toast.success('อัพเดทสถานะคำสั่งซื้อสำเร็จ');
  };

  const resetForm = () => {
    setEditingMenu(null);
    setFormData({
      menu_name: '',
      restaurant_id: 1,
      description: '',
      price: 0,
      image_url: '',
      status: 'available'
    });
  };

  const getRestaurantName = (restaurantId) => {
    return mockRestaurants.find(r => r.restaurant_id === restaurantId)?.restaurant_name || '';
  };

  const getOrderDetails = (orderId) => {
    const savedDetails = localStorage.getItem('orderDetails');
    const details = savedDetails ? JSON.parse(savedDetails) : mockOrderDetails;
    return details.filter(d => d.order_id === orderId);
  };

  const getMenuName = (menuId) => {
    return menuItems.find(m => m.menu_id === menuId)?.menu_name || 'ไม่ทราบชื่อ';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl mb-6">แดชบอร์ดแอดมิน</h1>

      <Tabs defaultValue="menu" className="space-y-6">
        <TabsList>
          <TabsTrigger value="menu">จัดการเมนู</TabsTrigger>
          <TabsTrigger value="orders">จัดการคำสั่งซื้อ</TabsTrigger>
        </TabsList>

        <TabsContent value="menu" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl">รายการเมนูทั้งหมด</h2>
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="size-4" />
                  เพิ่มเมนูใหม่
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingMenu ? 'แก้ไขเมนู' : 'เพิ่มเมนูใหม่'}</DialogTitle>
                  <DialogDescription>กรอกข้อมูลเมนูอาหาร</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>ชื่อเมนู</Label>
                    <Input
                      value={formData.menu_name}
                      onChange={(e) => setFormData({ ...formData, menu_name: e.target.value })}
                      placeholder="ผัดไทย"
                    />
                  </div>
                  <div>
                    <Label>ร้านอาหาร</Label>
                    <Select
                      value={formData.restaurant_id.toString()}
                      onValueChange={(value) => setFormData({ ...formData, restaurant_id: parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {mockRestaurants.map(restaurant => (
                          <SelectItem key={restaurant.restaurant_id} value={restaurant.restaurant_id.toString()}>
                            {restaurant.restaurant_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>คำอธิบาย</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="รายละเอียดเมนู..."
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>ราคา (บาท)</Label>
                    <Input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <Label>URL รูปภาพ</Label>
                    <Input
                      value={formData.image_url}
                      onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>
                  <div>
                    <Label>สถานะ</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">พร้อมขาย</SelectItem>
                        <SelectItem value="unavailable">ไม่พร้อมขาย</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => {
                    resetForm();
                    setIsDialogOpen(false);
                  }}>
                    ยกเลิก
                  </Button>
                  <Button onClick={handleSubmit}>
                    {editingMenu ? 'บันทึก' : 'เพิ่มเมนู'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {menuItems.map(menu => (
              <Card key={menu.menu_id}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <img
                      src={menu.image_url}
                      alt={menu.menu_name}
                      className="size-24 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="mb-1">{menu.menu_name}</h3>
                          <p className="text-sm text-gray-600">{getRestaurantName(menu.restaurant_id)}</p>
                        </div>
                        <Badge variant={menu.status === 'available' ? 'secondary' : 'destructive'}>
                          {menu.status === 'available' ? 'พร้อมขาย' : 'ไม่พร้อมขาย'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{menu.description}</p>
                      <p className="text-lg">฿{menu.price.toFixed(2)}</p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleMenuStatus(menu.menu_id)}
                        className="gap-2"
                      >
                        {menu.status === 'available' ? (
                          <>
                            <XCircle className="size-4" />
                            ปิดขาย
                          </>
                        ) : (
                          <>
                            <CheckCircle className="size-4" />
                            เปิดขาย
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(menu)}
                        className="gap-2"
                      >
                        <Pencil className="size-4" />
                        แก้ไข
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(menu.menu_id)}
                        className="gap-2"
                      >
                        <Trash2 className="size-4" />
                        ลบ
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>คำสั่งซื้อทั้งหมด</CardTitle>
              <CardDescription>จัดการสถานะคำสั่งซื้อ</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>รหัส</TableHead>
                    <TableHead>วันที่</TableHead>
                    <TableHead>รายการ</TableHead>
                    <TableHead>ยอดรวม</TableHead>
                    <TableHead>สถานะ</TableHead>
                    <TableHead>จัดการ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders
                    .sort((a, b) => new Date(b.order_date).getTime() - new Date(a.order_date).getTime())
                    .map(order => {
                      const details = getOrderDetails(order.order_id);
                      return (
                        <TableRow key={order.order_id}>
                          <TableCell>#{order.order_id}</TableCell>
                          <TableCell>
                            {new Date(order.order_date).toLocaleDateString('th-TH')}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {details.map(d => (
                                <div key={d.order_detail_id}>
                                  {getMenuName(d.menu_id)} x{d.quantity}
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>฿{order.total_price.toFixed(2)}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                order.status === 'delivered' ? 'default' :
                                order.status === 'cancelled' ? 'destructive' :
                                'secondary'
                              }
                            >
                              {order.status === 'pending' && 'รอดำเนินการ'}
                              {order.status === 'cooking' && 'กำลังทำอาหาร'}
                              {order.status === 'delivered' && 'จัดส่งแล้ว'}
                              {order.status === 'cancelled' && 'ยกเลิก'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={order.status}
                              onValueChange={(value) => updateOrderStatus(order.order_id, value)}
                            >
                              <SelectTrigger className="w-40">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">รอดำเนินการ</SelectItem>
                                <SelectItem value="cooking">กำลังทำอาหาร</SelectItem>
                                <SelectItem value="delivered">จัดส่งแล้ว</SelectItem>
                                <SelectItem value="cancelled">ยกเลิก</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
