import { useNavigate } from 'react-router';
import { useCart } from '../context/CartContext.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Separator } from '../components/ui/separator';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';

export function CartPage() {
  const { cart, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error('ตะกร้าสินค้าว่างเปล่า');
      return;
    }

    // สร้างคำสั่งซื้อใหม่
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const orderDetails = JSON.parse(localStorage.getItem('orderDetails') || '[]');

    const newOrderId = orders.length + 1;
    const newOrder = {
      order_id: newOrderId,
      user_id: currentUser?.user_id,
      order_date: new Date().toISOString(),
      total_price: getTotalPrice(),
      status: 'pending'
    };

    const newOrderDetails = cart.map((item, index) => ({
      order_detail_id: orderDetails.length + index + 1,
      order_id: newOrderId,
      menu_id: item.menu.menu_id,
      quantity: item.quantity,
      price: item.menu.price
    }));

    localStorage.setItem('orders', JSON.stringify([...orders, newOrder]));
    localStorage.setItem('orderDetails', JSON.stringify([...orderDetails, ...newOrderDetails]));

    clearCart();
    toast.success('สั่งอาหารสำเร็จ!');
    navigate('/orders');
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center">
          <ShoppingBag className="size-24 mx-auto text-gray-300 mb-4" />
          <h2 className="text-2xl mb-2">ตะกร้าสินค้าว่างเปล่า</h2>
          <p className="text-gray-600 mb-6">ยังไม่มีสินค้าในตะกร้า เริ่มสั่งอาหารกันเลย!</p>
          <Button onClick={() => navigate('/')}>
            เลือกเมนูอาหาร
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl mb-6">ตะกร้าสินค้า</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {cart.map(item => (
            <Card key={item.menu.menu_id}>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <img
                    src={item.menu.image_url}
                    alt={item.menu.menu_name}
                    className="size-24 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h3 className="mb-1">{item.menu.menu_name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{item.menu.description}</p>
                    <p className="text-lg">฿{item.menu.price.toFixed(2)}</p>
                  </div>
                  <div className="flex flex-col justify-between items-end">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFromCart(item.menu.menu_id)}
                    >
                      <Trash2 className="size-4 text-red-500" />
                    </Button>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="size-8"
                        onClick={() => updateQuantity(item.menu.menu_id, item.quantity - 1)}
                      >
                        <Minus className="size-3" />
                      </Button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="size-8"
                        onClick={() => updateQuantity(item.menu.menu_id, item.quantity + 1)}
                      >
                        <Plus className="size-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>สรุปคำสั่งซื้อ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.map(item => (
                <div key={item.menu.menu_id} className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    {item.menu.menu_name} x{item.quantity}
                  </span>
                  <span>฿{(item.menu.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <Separator />
              <div className="flex justify-between text-lg">
                <span>ยอดรวม</span>
                <span className="text-orange-500">฿{getTotalPrice().toFixed(2)}</span>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-2">
              <Button className="w-full" onClick={handleCheckout}>
                สั่งอาหาร
              </Button>
              <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                สั่งเพิ่ม
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
