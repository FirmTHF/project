import { useState, useEffect } from 'react';
import { mockRestaurants, mockMenu } from '../data/mockData.js';
import { useCart } from '../context/CartContext.jsx';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Search, Plus, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';

export function HomePage() {
  const [restaurants] = useState(mockRestaurants);
  const [menuItems, setMenuItems] = useState(mockMenu);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const { addToCart } = useCart();

  useEffect(() => {
    const savedMenu = localStorage.getItem('menu');
    if (savedMenu) {
      setMenuItems(JSON.parse(savedMenu));
    }
  }, []);

  const filteredMenu = menuItems.filter(menu => {
    const matchesSearch = menu.menu_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         menu.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRestaurant = !selectedRestaurant || menu.restaurant_id === selectedRestaurant;
    return matchesSearch && matchesRestaurant;
  });

  const handleAddToCart = (menu) => {
    if (menu.status === 'unavailable') {
      toast.error('สินค้านี้ไม่พร้อมขาย');
      return;
    }
    addToCart(menu);
    toast.success(`เพิ่ม ${menu.menu_name} ลงในตะกร้าแล้ว`);
  };

  const getRestaurantName = (restaurantId) => {
    return restaurants.find(r => r.restaurant_id === restaurantId)?.restaurant_name || '';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">ยินดีต้อนรับสู่ระบบสั่งอาหารออนไลน์</h1>
        <p className="text-gray-600">เลือกเมนูอาหารที่คุณชอบจากร้านต่างๆ</p>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
          <Input
            placeholder="ค้นหาเมนูอาหาร..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="w-full justify-start flex-wrap h-auto">
          <TabsTrigger value="all" onClick={() => setSelectedRestaurant(null)}>
            ทั้งหมด
          </TabsTrigger>
          {restaurants.map(restaurant => (
            <TabsTrigger
              key={restaurant.restaurant_id}
              value={restaurant.restaurant_id.toString()}
              onClick={() => setSelectedRestaurant(restaurant.restaurant_id)}
            >
              {restaurant.restaurant_name}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {filteredMenu.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-gray-500">ไม่พบเมนูอาหารที่ค้นหา</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMenu.map(menu => (
            <Card key={menu.menu_id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={menu.image_url}
                  alt={menu.menu_name}
                  className="w-full h-48 object-cover"
                />
                {menu.status === 'unavailable' && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Badge variant="destructive" className="text-lg">หมด</Badge>
                  </div>
                )}
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{menu.menu_name}</CardTitle>
                    <CardDescription className="text-sm mt-1">
                      {getRestaurantName(menu.restaurant_id)}
                    </CardDescription>
                  </div>
                  <Badge variant={menu.status === 'available' ? 'secondary' : 'destructive'}>
                    {menu.status === 'available' ? 'พร้อมขาย' : 'ไม่พร้อมขาย'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 line-clamp-2">{menu.description}</p>
                <p className="text-2xl mt-4">฿{menu.price.toFixed(2)}</p>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full gap-2"
                  onClick={() => handleAddToCart(menu)}
                  disabled={menu.status === 'unavailable'}
                >
                  <ShoppingCart className="size-4" />
                  เพิ่มลงตะกร้า
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
