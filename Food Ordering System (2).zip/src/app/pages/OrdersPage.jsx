import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { mockOrders, mockOrderDetails, mockMenu } from '../data/mockData.js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { Clock, CheckCircle, XCircle, ChefHat } from 'lucide-react';

export function OrdersPage() {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState([]);
  const [orderDetails, setOrderDetails] = useState([]);

  useEffect(() => {
    const savedOrders = localStorage.getItem('orders');
    const savedOrderDetails = localStorage.getItem('orderDetails');

    if (savedOrders) {
      const allOrders = JSON.parse(savedOrders);
      setOrders(allOrders.filter(o => o.user_id === currentUser?.user_id));
    } else {
      setOrders(mockOrders.filter(o => o.user_id === currentUser?.user_id));
    }

    if (savedOrderDetails) {
      setOrderDetails(JSON.parse(savedOrderDetails));
    } else {
      setOrderDetails(mockOrderDetails);
    }
  }, [currentUser]);

  const getStatusBadge = (status) => {
    const config = {
      pending: { label: 'รอดำเนินการ', variant: 'secondary', icon: Clock },
      cooking: { label: 'กำลังทำอาหาร', variant: 'default', icon: ChefHat },
      delivered: { label: 'จัดส่งแล้ว', variant: 'default', icon: CheckCircle },
      cancelled: { label: 'ยกเลิก', variant: 'destructive', icon: XCircle }
    };
    const statusConfig = config[status] || config.pending;
    const Icon = statusConfig.icon;

    return (
      <Badge variant={statusConfig.variant} className="gap-1">
        <Icon className="size-3" />
        {statusConfig.label}
      </Badge>
    );
  };

  const getOrderItems = (orderId) => {
    return orderDetails.filter(od => od.order_id === orderId);
  };

  const getMenuName = (menuId) => {
    return mockMenu.find(m => m.menu_id === menuId)?.menu_name || 'ไม่ทราบชื่อ';
  };

  if (orders.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center">
          <Clock className="size-24 mx-auto text-gray-300 mb-4" />
          <h2 className="text-2xl mb-2">ยังไม่มีประวัติคำสั่งซื้อ</h2>
          <p className="text-gray-600">เริ่มสั่งอาหารเพื่อดูประวัติการสั่งซื้อของคุณ</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl mb-6">ประวัติคำสั่งซื้อ</h1>

      <div className="space-y-4">
        {orders
          .sort((a, b) => new Date(b.order_date).getTime() - new Date(a.order_date).getTime())
          .map(order => {
            const items = getOrderItems(order.order_id);
            return (
              <Card key={order.order_id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>คำสั่งซื้อ #{order.order_id}</CardTitle>
                      <CardDescription>
                        {new Date(order.order_date).toLocaleString('th-TH', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </CardDescription>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {items.map(item => (
                      <div key={item.order_detail_id} className="flex justify-between text-sm">
                        <span className="text-gray-600">
                          {getMenuName(item.menu_id)} x{item.quantity}
                        </span>
                        <span>฿{(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                    <Separator className="my-2" />
                    <div className="flex justify-between">
                      <span>ยอดรวม</span>
                      <span className="text-lg text-orange-500">
                        ฿{order.total_price.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
      </div>
    </div>
  );
}
