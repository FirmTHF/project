// Mock Data based on Database Schema

// Mock Users
export const mockUsers = [
  {
    user_id: 1,
    name: 'สมชาย ใจดี',
    email: 'customer@test.com',
    password: 'password123',
    role: 'customer',
    created_at: '2024-01-15T10:00:00Z'
  },
  {
    user_id: 2,
    name: 'แอดมิน ระบบ',
    email: 'admin@test.com',
    password: 'admin123',
    role: 'admin',
    created_at: '2024-01-01T08:00:00Z'
  },
  {
    user_id: 3,
    name: 'สมหญิง รักสะอาด',
    email: 'somying@test.com',
    password: 'password123',
    role: 'customer',
    created_at: '2024-02-10T14:30:00Z'
  }
];

// Mock Restaurants
export const mockRestaurants = [
  {
    restaurant_id: 1,
    restaurant_name: 'ร้านอาหารไทยแท้',
    address: '123 ถนนสุขุมวิท กรุงเทพฯ 10110',
    phone: '02-123-4567',
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    restaurant_id: 2,
    restaurant_name: 'Pizza House',
    address: '456 ถนนพระราม 4 กรุงเทพฯ 10500',
    phone: '02-234-5678',
    created_at: '2024-01-05T00:00:00Z'
  },
  {
    restaurant_id: 3,
    restaurant_name: 'Burger Station',
    address: '789 ถนนสีลม กรุงเทพฯ 10500',
    phone: '02-345-6789',
    created_at: '2024-01-10T00:00:00Z'
  }
];

// Mock Menu
export const mockMenu = [
  // ร้านอาหารไทยแท้
  {
    menu_id: 1,
    restaurant_id: 1,
    menu_name: 'ผัดไทย',
    description: 'เส้นผัดไทยรสชาติต้นตำรับ ใส่กุ้งสด ถั่วงอก และเครื่องเคียงครบ',
    price: 60,
    image_url: 'https://images.unsplash.com/photo-1729708475167-71a6eb3cd741?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGFpJTIwZm9vZCUyMHBhZCUyMHRoYWl8ZW58MXx8fHwxNzcxMjE1OTI0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 2,
    restaurant_id: 1,
    menu_name: 'แกงเขียวหวานไก่',
    description: 'แกงเขียวหวานไก่กะทิสดใหม่ รสชาติกลมกล่อม เผ็ดร้อนกำลังดี',
    price: 70,
    image_url: 'https://images.unsplash.com/photo-1605461682195-9fd4d079a41d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGN1cnJ5JTIwdGhhaSUyMGZvb2R8ZW58MXx8fHwxNzcxMzM5Njk0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 3,
    restaurant_id: 1,
    menu_name: 'ต้มยำกุ้ง',
    description: 'ต้มยำกุ้งน้ำข้น รสจัดจ้าน เผ็ดเปรี้ยวกำลังดี',
    price: 120,
    image_url: 'https://images.unsplash.com/photo-1702940860770-f742273de15c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b20lMjB5dW0lMjBzb3VwJTIwdGhhaXxlbnwxfHx8fDE3NzEzMzk2OTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 4,
    restaurant_id: 1,
    menu_name: 'ข้าวผัดกุ้ง',
    description: 'ข้าวผัดกุ้งสด ใส่ไข่ ผักชี และเครื่องเคียง',
    price: 50,
    image_url: 'https://images.unsplash.com/photo-1581184953963-d15972933db1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllZCUyMHJpY2UlMjBhc2lhbiUyMGZvb2R8ZW58MXx8fHwxNzcxMzM5Njk1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 5,
    restaurant_id: 1,
    menu_name: 'ข้าวเหนียวมะม่วง',
    description: 'ข้าวเหนียวหอมมะลิ เสิร์ฟพร้อมมะม่วงสุกหวาน และน้ำกะทิ',
    price: 45,
    image_url: 'https://images.unsplash.com/photo-1582801205465-c0d029e85a1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMHN0aWNreSUyMHJpY2UlMjBkZXNzZXJ0fGVufDF8fHx8MTc3MTMzOTY5NXww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  // Pizza House
  {
    menu_id: 6,
    restaurant_id: 2,
    menu_name: 'Margherita Pizza',
    description: 'พิซซ่ามาการิต้าสูตรดั้งเดิม โมสซาเรลลา มะเขือเทศ และใบโหระพา',
    price: 250,
    image_url: 'https://images.unsplash.com/photo-1663858835211-3883764dcd52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMHJlc3RhdXJhbnQlMjBmb29kfGVufDF8fHx8MTc3MTIzNzM0OHww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 7,
    restaurant_id: 2,
    menu_name: 'Carbonara Pasta',
    description: 'สปาเก็ตตี้คาโบนาร่า เบคอน ครีม และพาร์เมซาน',
    price: 180,
    image_url: 'https://images.unsplash.com/photo-1588013273468-315fd88ea34c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFnaGV0dGklMjBjYXJib25hcmElMjBwYXN0YXxlbnwxfHx8fDE3NzEzMDA4OTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 8,
    restaurant_id: 2,
    menu_name: 'Hawaiian Pizza',
    description: 'พิซซ่าฮาวายเอี้ยน แหม ไก่ สับปะรด และชีส',
    price: 280,
    image_url: 'https://images.unsplash.com/photo-1663858835211-3883764dcd52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMHJlc3RhdXJhbnQlMjBmb29kfGVufDF8fHx8MTc3MTIzNzM0OHww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'unavailable'
  },
  // Burger Station
  {
    menu_id: 9,
    restaurant_id: 3,
    menu_name: 'Classic Burger',
    description: 'เบอร์เกอร์เนื้อวัวแท้ 100% ผัก ชีส และซอสพิเศษ',
    price: 120,
    image_url: 'https://images.unsplash.com/photo-1656439659132-24c68e36b553?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXJnZXIlMjBmYXN0JTIwZm9vZHxlbnwxfHx8fDE3NzEzMDQxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  },
  {
    menu_id: 10,
    restaurant_id: 3,
    menu_name: 'Cheese Burger',
    description: 'เบอร์เกอร์ชีสดับเบิล เนื้อวัว 2 ชั้น ชีสเยิ้ม',
    price: 150,
    image_url: 'https://images.unsplash.com/photo-1656439659132-24c68e36b553?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXJnZXIlMjBmYXN0JTIwZm9vZHxlbnwxfHx8fDE3NzEzMDQxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'available'
  }
];

// Mock Orders
export const mockOrders = [
  {
    order_id: 1,
    user_id: 1,
    order_date: '2024-02-15T12:30:00Z',
    total_price: 330,
    status: 'delivered'
  },
  {
    order_id: 2,
    user_id: 1,
    order_date: '2024-02-16T18:45:00Z',
    total_price: 250,
    status: 'cooking'
  },
  {
    order_id: 3,
    user_id: 3,
    order_date: '2024-02-17T10:15:00Z',
    total_price: 540,
    status: 'pending'
  }
];

// Mock Order Details
export const mockOrderDetails = [
  // Order 1
  {
    order_detail_id: 1,
    order_id: 1,
    menu_id: 1,
    quantity: 2,
    price: 60
  },
  {
    order_detail_id: 2,
    order_id: 1,
    menu_id: 2,
    quantity: 1,
    price: 70
  },
  {
    order_detail_id: 3,
    order_id: 1,
    menu_id: 3,
    quantity: 1,
    price: 120
  },
  {
    order_detail_id: 4,
    order_id: 1,
    menu_id: 5,
    quantity: 1,
    price: 45
  },
  // Order 2
  {
    order_detail_id: 5,
    order_id: 2,
    menu_id: 6,
    quantity: 1,
    price: 250
  },
  // Order 3
  {
    order_detail_id: 6,
    order_id: 3,
    menu_id: 9,
    quantity: 2,
    price: 120
  },
  {
    order_detail_id: 7,
    order_id: 3,
    menu_id: 10,
    quantity: 2,
    price: 150
  }
];
