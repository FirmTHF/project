import { Link, useLocation } from 'react-router';
import { ShoppingCart, User, LogOut, Home, History, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useCart } from '../context/CartContext.jsx';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function Navbar() {
  const { currentUser, logout } = useAuth();
  const { getTotalItems } = useCart();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-orange-500 text-white p-2 rounded-lg">
                <ShoppingCart className="size-6" />
              </div>
              <span className="text-xl">Food Ordering</span>
            </Link>

            {currentUser && (
              <div className="hidden md:flex items-center gap-4">
                <Link to="/">
                  <Button
                    variant={isActive('/') ? 'default' : 'ghost'}
                    size="sm"
                    className="gap-2"
                  >
                    <Home className="size-4" />
                    หน้าหลัก
                  </Button>
                </Link>
                <Link to="/orders">
                  <Button
                    variant={isActive('/orders') ? 'default' : 'ghost'}
                    size="sm"
                    className="gap-2"
                  >
                    <History className="size-4" />
                    ประวัติคำสั่งซื้อ
                  </Button>
                </Link>
                {currentUser.role === 'admin' && (
                  <Link to="/admin">
                    <Button
                      variant={isActive('/admin') ? 'default' : 'ghost'}
                      size="sm"
                      className="gap-2"
                    >
                      <LayoutDashboard className="size-4" />
                      Admin
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            {currentUser ? (
              <>
                <Link to="/cart" className="relative">
                  <Button
                    variant={isActive('/cart') ? 'default' : 'ghost'}
                    size="icon"
                  >
                    <ShoppingCart className="size-5" />
                  </Button>
                  {getTotalItems() > 0 && (
                    <Badge className="absolute -top-1 -right-1 size-5 flex items-center justify-center p-0">
                      {getTotalItems()}
                    </Badge>
                  )}
                </Link>

                <div className="flex items-center gap-2">
                  <User className="size-5 text-gray-600" />
                  <span className="hidden sm:inline">{currentUser.name}</span>
                  {currentUser.role === 'admin' && (
                    <Badge variant="secondary">Admin</Badge>
                  )}
                </div>

                <Button variant="outline" size="sm" onClick={logout} className="gap-2">
                  <LogOut className="size-4" />
                  <span className="hidden sm:inline">ออกจากระบบ</span>
                </Button>
              </>
            ) : (
              <Link to="/login">
                <Button>เข้าสู่ระบบ</Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
