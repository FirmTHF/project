
  # Food Ordering System

  This is a code bundle for Food Ordering System. The original project is available at https://www.figma.com/design/G6dHNrE0GFrs9eTyX2tN40/Food-Ordering-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  